# Example configuration

```powershell
Import-Module .\DryActiveDirectory.psd1
Import-DryADConfiguration -VariablesPath .\Example\VariablesPath.json -ConfigurationPath .\Example\ConfigurationPath -ComputerName "SomeComputername" -ADSite "S5" -DomainController <DC>
````




